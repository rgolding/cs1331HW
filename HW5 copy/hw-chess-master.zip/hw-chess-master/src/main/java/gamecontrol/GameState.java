package gamecontrol;

public interface GameState {
    boolean isGameOver();
}
